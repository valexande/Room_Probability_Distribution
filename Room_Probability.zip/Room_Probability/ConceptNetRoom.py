import requests

class ConceptNet():

    def __init__(self, object):
        self.object = object

    def myfunc(self):
        return 'http://api.conceptnet.io/c/en/' + self.object + '?offset=0&limit=1000'

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def FindRoom(self):

        lst = []
        lst2 = []
        values = self.myfunc()
        respone = requests.get(values)
        obj = respone.json()
        lst0 = []
        for relation in obj['edges']:
            if ('wordnet' in relation['sources'][0]['@id']) or ('verbosity' in relation['sources'][0]['@id']):
                lst0.append(1)
            else:
                lst0.append(0)

        lst = [relation['rel']['@id'] for relation in obj['edges']]
        lst2 = [relation['@id'] for relation in obj['edges']]
        lst3 = [relation['weight'] for relation in obj['edges']]
        cleaning_one = self.cleaning_entities(lst2, lst, lst3)
        purposeCN = self.cleaning_entities_second(cleaning_one[1], cleaning_one[0])



        listCN = []
        for property in purposeCN[0]:
            for entity in purposeCN[0][property]:
                listCN = listCN + [entity.replace(self.object, "")]


        return listCN

    def cleaning_entities(self, entities, properties, weights):
        list1 = []
        entity_property = {}
        for i in range(len(entities)):
            first_cleaning = entities[i].replace('/a/[', '').replace(']', '')
            for j in range(len(properties)):
                if properties[j] + '/' in first_cleaning:
                    second_cleaning = first_cleaning.replace(properties[j] + '/', '').replace(',', '')
                    if entity_property.get(properties[j]) == None:
                        entity_property.setdefault(properties[j], []).append(second_cleaning)
                    else:
                        entity_property[properties[j]].append(second_cleaning)
                    break
            list1.append((second_cleaning, weights[i]))
        desired_properties = ['/r/AtLocation', '/r/LocatedNear']
        list_key_help = []
        for key in entity_property.keys():
            list_key_help.append(key)

        entity_property_keep = {}
        for property in desired_properties:
            if property in list_key_help:
                entity_property_keep[property] = entity_property[property]
            else:
                entity_property_keep[property] = []

        return list1, entity_property_keep

    def cleaning_entities_second(self, entities_observed, perceived_weights):
        for observed in entities_observed:
            for entity in range(len(entities_observed[observed]) - 1, -1, -1):
                if not (entities_observed[observed][entity].count("/en/") == 2):
                    del entities_observed[observed][entity]
                else:
                    for perceived_entity in self.object:
                        if (('/c/en/' + perceived_entity + '/') in entities_observed[observed][entity]):
                            entities_observed[observed][entity] = entities_observed[observed][entity].replace(
                                '/c/en/' + perceived_entity + '/', '')
                        if (('/c/en' + perceived_entity + '/n/') in entities_observed[observed][entity]):
                            entities_observed[observed][entity] = entities_observed[observed][entity].replace(
                                '/c/en/' + perceived_entity + '/n/', '')

        for observed in entities_observed:
            annotator = 0
            for i in entities_observed[observed]:
                if ('wn/' in i):
                    entities_observed[observed][annotator] = entities_observed[observed][annotator].replace('wn/', '_')
                if ('/n/' in i):
                    entities_observed[observed][annotator] = entities_observed[observed][annotator].replace('/n/', '')
                if ('/v/' in i):
                    entities_observed[observed][annotator] = entities_observed[observed][annotator].replace('/v/', '')
                if ('/a/' in i):
                    entities_observed[observed][annotator] = entities_observed[observed][annotator].replace('/a/', '')
                if ('/c/en/' in i):
                    entities_observed[observed][annotator] = entities_observed[observed][annotator].replace('/c/en/', '')
                if ('/' in i):
                    entities_observed[observed][annotator] = entities_observed[observed][annotator].replace('/', '')
                annotator += 1

        for observed in entities_observed:
            entities_observed[observed] = self.Remove(entities_observed[observed])


        helper_list_weights = []
        for property in entities_observed:
            for entity in entities_observed[property]:
                helper_list_weights.append(entity.replace(self.object, ""))

        list_purpose_weights = []
        for entity in helper_list_weights:
            for weight in perceived_weights:
                if entity in weight[0]:
                    list_purpose_weights.append((entity, weight[1]))
        return entities_observed, list_purpose_weights