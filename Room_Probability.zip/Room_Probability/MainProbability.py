import wikipedia
from ConceptNetRoom import *
from IKEAProbability import *
from VirtualHomeProb import *
from Ai2ThorProbability import *
import textdistance

def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final


files = open("objects5.txt", "r")
listRoom = ['kitchen', 'bedroom', 'bathroom', 'dining_room', 'living_room', 'office', 'hallway', 'kids']
Paths = []
k = 0
for f in files.readlines():
    entity = f.replace("\n", "").replace("_", " ").replace("-", " ").replace(" of ", " ").replace(" for ", " ").\
    replace(" Sliced", "").lower()
    entity = list(entity.split(" "))
    if len(entity) > 2:
        entity = entity[2].capitalize()
    elif len(entity) == 2:
        entity = entity[1].capitalize()
    else:
        entity = entity[0].capitalize()

    obj = entity
    print(obj)
    try:
        wikiSearch = wikipedia.search(obj, results=1)[0]
        wikiPage = wikipedia.page(wikiSearch).content
        wikiCategories = wikipedia.page(wikiSearch).categories
    except Exception as e:
        wikiPage = []
        wikiCategories = []
        probWiki = 0

    if type(wikiPage) == list:
        wikiHelp = ""
        for i in range(len(wikiPage)):
            wikiHelp = wikiHelp + wikiPage[i]
        wikiPage = wikiHelp

    wikiPage = wikiPage.replace("\n", " ").replace(")", "").replace("(", "").replace("\"", "").replace("\'", "").\
               replace("!", "").replace("?", "").replace(",", "").replace("=", "").replace("-", "").replace("    ", "").\
               replace("  ", "").replace("   ", "").replace("'s", "").lower()
    wikiPage = ''.join([i for i in wikiPage if not i.isdigit()])
    wikiPage = wikiPage.lower()
    wikiPage = wikiPage.split(" ")

    wikiCategoriesNew = []
    for category in wikiCategories:
        category = category.replace("\n", " ").replace(")", "").replace("(", "").replace("\"", "").replace("\'", "").\
               replace("!", "").replace("?", "").replace(",", "").replace("=", "").replace("-", "").replace("    ", "").\
               replace("  ", "").replace("   ", "").replace("'s", "").lower()
        category = ''.join([i for i in category if not i.isdigit()])
        category = category.lower()
        wikiCategoriesNew = wikiCategoriesNew + [category]

    wikiInfo = wikiPage + wikiCategoriesNew
    wikiRoomProb = []
    for room in listRoom:
        for wiki in wikiInfo:
            if textdistance.ratcliff_obershelp(room.replace("_", " "), wiki) > 0.2:
            #if room.replace("_", " ") in wikiInfo:
                wikiRoomProb.append((room, 0.2))
                break
            else:
                wikiRoomProb.append((room, 0))
    wikiRoomProb = sorted(wikiRoomProb, key=lambda x: x[1], reverse=True)
    wikiRoomProb = Remove(wikiRoomProb)
    visitedWiki = set()
    wikiProbHelp = []
    for a, b in wikiRoomProb:
        if not a in visitedWiki:
            visitedWiki.add(a)
            wikiProbHelp.append((a, b))
    #print(wikiProbHelp)



    cn = ConceptNet(obj)
    RoomCN = cn.FindRoom()
    if RoomCN == []:
        RoomCN = [" "]

    CNRoomProb = []
    for room in listRoom:
       for CN in RoomCN:
            if textdistance.ratcliff_obershelp(room.replace("_", " "), CN) > 0.2:
        #if room.replace("_", " ") in RoomCN:
                CNRoomProb.append((room, 0.2))
                break
            else:
                CNRoomProb.append((room, 0))
    scoretu = 0
    for tu in CNRoomProb:
        scoretu = scoretu + tu[1]
    CNRoomProbHelper = []
    if scoretu == 0:
        for helper in RoomCN:
            helper = helper.replace("\n", " ").replace(")", "").replace("(", "").replace("\"", "").replace("\'", "").\
               replace("!", "").replace("?", "").replace(",", "").replace("=", "").replace("-", "").replace("    ", "").\
               replace("  ", "").replace("   ", "").replace("'s", "")
            try:
                cn = ConceptNet(helper)
                RoomCN = cn.FindRoom()
                for room in listRoom:
                    for CN in RoomCN:
                    #if room.replace("_", " ") in RoomCN:
                        if textdistance.ratcliff_obershelp(room.replace("_", " "), CN) > 0.5:
                            CNRoomProbHelper.append((room, 0.2))
                            break
                        else:
                            CNRoomProbHelper.append((room, 0))
            except Exception as e:
                continue
        CNRoomProbHelper = Remove(CNRoomProbHelper)
        CNRoomProbHelper = sorted(CNRoomProbHelper, key = lambda x: x[1], reverse=True)
        visited = set()
        OutputCNRoom = []
        for a, b in CNRoomProbHelper:
            if not a in visited:
                visited.add(a)
                OutputCNRoom.append((a, b))

    if CNRoomProbHelper != []:
        CNRoomProb = OutputCNRoom
    #    print(CNRoomProb)
    #else:
    #    print(CNRoomProb)



    ikeaPath = IKEA(obj, listRoom)
    ikeaProb = ikeaPath.RoomIKEA()
    if ikeaProb == []:
        for room in listRoom:
            ikeaProb.append((room, 0))
    #print(ikeaProb)



    virtual = VirtualHome(obj, listRoom)
    virtualProb = virtual.objectRoom()
    if virtualProb == []:
        for room in listRoom:
            virtualProb.append((room, 0))
    #print(virtualProb)


    ai2 = AI2THOR(obj, listRoom)
    ai2Prob = ai2.ai2thorRoom()
    if ai2Prob == []:
        for room in listRoom:
            ai2Prob.append((room, 0))
    #print(ai2Prob)
    final = list()
    final.append(("kitchen", wikiProbHelp[0][1] + CNRoomProb[0][1] + ikeaProb[0][1] + virtualProb[0][1] + ai2Prob[0][1]))
    final.append(("bedroom", wikiProbHelp[1][1] + CNRoomProb[1][1] + ikeaProb[1][1] + virtualProb[1][1] + ai2Prob[1][1]))
    final.append(("bathroom", wikiProbHelp[2][1] + CNRoomProb[2][1] + ikeaProb[2][1] + virtualProb[2][1] + ai2Prob[2][1]))
    final.append(("dining_room", wikiProbHelp[3][1] + CNRoomProb[3][1] + ikeaProb[3][1] + virtualProb[3][1] + ai2Prob[3][1]))
    final.append(("living_room", wikiProbHelp[4][1] + CNRoomProb[4][1] + ikeaProb[4][1] + virtualProb[4][1] + ai2Prob[4][1]))
    final.append(("office", wikiProbHelp[5][1] + CNRoomProb[5][1] + ikeaProb[5][1] + virtualProb[5][1] + ai2Prob[5][1]))
    final.append(("hallway", wikiProbHelp[6][1] + CNRoomProb[6][1] + ikeaProb[6][1] + virtualProb[6][1] + ai2Prob[6][1]))
    final.append(("kids", wikiProbHelp[7][1] + CNRoomProb[7][1] + ikeaProb[7][1] + virtualProb[7][1] + ai2Prob[7][1]))
    print(final)
    print("         ")

files.close()