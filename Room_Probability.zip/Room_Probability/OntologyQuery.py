from subprocess import PIPE, run

class Ontology():


    def ontology_parsing(self):  ##Gets the query and return rsults form local ontology
        f = open('SPARQL_Query.txt', 'r')
        query_line = ""
        for line in f:
            query_line = query_line + line
        query = query_line.replace('\n', ' ')
        query = ' '.join(query.split())
        f.close()
        sparql_results = self.compile_java('SoCoLA.jar', query)

        return sparql_results


    def compile_java(self, java_file, query):  ##Makes the display of the results from our ontology
        p = run(['java', '-jar', java_file], stdout=PIPE, input=query, encoding='utf-8')
        results = list(p.stdout)
        arrays = [[results[0]]]
        for i in range(1, len(results)):
            if results[i] != '\n':
                arrays[len(arrays) - 1].append([results[i]])
            else:  # otherwise
                arrays.append([])  # Make a new sub-array

        list_with_answers = []
        for i in range(len(arrays)):
            results_sparql = ""
            for j in arrays[i]:
                results_sparql = results_sparql + j[0]
            list_with_answers.append(results_sparql)
        counter = 0
        list_results = []
        try:
            for answer in list_with_answers:
                if counter > 2:
                    answer = answer.split(") (")
                    result = ""
                    for entity in answer:
                        entity = entity.split("=")
                        if entity != ['']:
                            if '#' in str(entity[1]):
                                res = entity[1].split('#')[1].replace('>', '').replace(' )', '') + " "
                            else:
                                res = entity[1] + " "
                        result = result + res
                    list_results.append(result)
                counter += 1
            return list_results
        except Exception:
            pass