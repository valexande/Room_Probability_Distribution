import pandas as pn
import textdistance

class AI2THOR():
    def __init__(self, obj, rooms):
        self.obj = obj
        self.rooms = rooms

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def ai2thorRoom(self):
        df = pn.read_csv("AI2THOR_Rooms.csv",  encoding="utf-8", error_bad_lines=False)
        object = df['Object'].values
        kitchen = df['Kitchen'].values
        livingRoom = df['Living_Room'].values
        bedroom = df['Bedroom'].values
        bathroom = df['Bathroom'].values

        length = len(object)

        ai2Rooms = []
        for i in range(length):
            ai2Rooms.append([object[i].lower(), kitchen[i], livingRoom[i], bedroom[i], bathroom[i]])

        room = []
        for i in ai2Rooms:
            if self.obj.lower() in i[0]:
                room = i
        roomYes = []
        if room != []:
            if room[1] == "Yes":
                roomYes.append("kitchen")
            elif room[2] == "Yes":
                roomYes.append("living_room")
            elif room[3] == "Yes":
                roomYes.append("bedroom")
            elif room[4] == "Yes":
                roomYes.append("bathroom")

        roomYes = self.Remove(roomYes)
        ai2Prob = []
        for room in self.rooms:
            for Room in roomYes:
                if textdistance.ratcliff_obershelp(room, Room) > 0.2:
                    ai2Prob.append((room, 0.2))
                else:
                    ai2Prob.append((room, 0))
        ai2Prob = self.Remove(ai2Prob)
        return ai2Prob