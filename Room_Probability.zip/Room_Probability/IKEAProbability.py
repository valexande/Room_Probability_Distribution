import os, os.path
from nltk.corpus import wordnet as wn
import textdistance

class IKEA():

    def __init__(self, object, Room):
        self.object = object
        self.Room = Room
    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def RoomIKEA(self):
        wordnet = wn.synsets(self.object)[0]
        hypernym = wordnet.hypernyms()
        if len(hypernym) == 0:
            hypernym = ["&&&&&&&&&&"]
        listRooms = []
        for root, dirs, files in os.walk('D:/PhD_Projects/IKEA_DIMENSIONS_OK'):
            root = root.replace("/", "\\")
            root = root.split("IKEA_DIMENSIONS_OK")

            if self.object.lower() in root[1].lower():
                listRooms.append(root[1])
            if hypernym[0].name().lower() in root[1].lower():
                listRooms.append(root[1])

        listRooms = self.Remove(listRooms)


        ikeaProb = []
        for room in self.Room:
            for ikeaRoom in listRooms:
                if textdistance.ratcliff_obershelp(room, ikeaRoom) > 0.2:
                #if room in ikeaRoom.lower():
                    ikeaProb.append((room, 0.2))
                else:
                    ikeaProb.append((room, 0))
        ikeaProb = self.Remove(ikeaProb)

        return ikeaProb
