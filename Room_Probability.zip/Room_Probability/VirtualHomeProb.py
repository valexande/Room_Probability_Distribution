from OntologyQuery import *
import textdistance

class VirtualHome():


    def __init__(self, object, room):
        self.object = object
        self.room = room

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def objectRoom(self):
        counter = ['1', '2', '3', '4', '5']
        list_with_purposes = []
        for c in counter:
            try:
                f = open("SPARQL_Query.txt", "w")
                SPARQL = """PREFIX : <http://mapir.isa.uma.es/jotaraul/SoCoLA_Populated#>
                            PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                            PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                            SELECT DISTINCT ?object WHERE { ?class rdfs:subClassOf :Activities .
                                                            ?subClass rdfs:subClassOf ?class .
                                                            ?instance rdf:type ?subClass .
                                                            ?instance :listOfSteps ?list .
                                                            ?list rdf:rest*/rdf:first ?step .
                                                            ?step :object :""" + str(self.object.lower() + c) + """ .
                                                            ?list rdf:rest*/rdf:first ?step1 .
                                                            ?step1 :object ?object. }"""
                f.write(SPARQL)
                f.close()
                results = Ontology()
                results = results.ontology_parsing()
                results = self.Remove(results)
                if results != []:
                    list_with_purposes = list_with_purposes + results
            except Exception as e:
                continue
        list_with_purposes = self.Remove(list_with_purposes)


        for entity in range(len(list_with_purposes)):
            list_with_purposes[entity] = list_with_purposes[entity].replace("1 ", "").replace("2 ", "").replace("3 ", "")\
                .replace("4 ", "").replace("5 ", "")



        virtualProb =[]
        for room in self.room:
            for virtual in list_with_purposes:
                if textdistance.ratcliff_obershelp(room, virtual) > 0.2:
                   virtualProb.append((room, 0.2))
                else:
                    virtualProb.append((room, 0))

        virtualProb =self.Remove(virtualProb)
        virtualProb = sorted(virtualProb, key=lambda x: x[1], reverse=True)
        visited = set()
        OutputVirtualProb = []
        for a, b in virtualProb:
            if not a in visited:
                visited.add(a)
                OutputVirtualProb.append((a, b))
        OutputVirtualProb = self.Remove(OutputVirtualProb)
        return OutputVirtualProb